plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.babylon.flight"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.babylon.flight"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {
    // No external deps needed — pure WebView app
}
