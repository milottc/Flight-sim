# Babylon Flight 737 — Android App

A WebView wrapper for the Babylon Flight 737 simulator.

## Build Instructions

### Prerequisites
- Android Studio (Ladybug or newer) — https://developer.android.com/studio
- Android SDK 35 (installed via Android Studio)

### Steps
1. Open Android Studio
2. File → Open → select this folder (BabylonFlight)
3. Let Gradle sync (it downloads dependencies automatically)
4. Update `local.properties` with your SDK path if prompted (Android Studio does this automatically)
5. Connect your Android device or start an emulator
6. Click ▶ Run (or press Shift+F10)

### Build a signed APK for distribution
1. Build → Generate Signed Bundle/APK
2. Choose APK
3. Create a new keystore or use an existing one
4. Build → release

### Debug APK (no signing needed)
- Build → Build Bundle(s) / APK(s) → Build APK(s)
- APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

## App Details
- **Package**: com.babylon.flight
- **Min SDK**: Android 7.0 (API 24)
- **Target SDK**: Android 15 (API 35)
- **Orientation**: Landscape only
- **Permissions**: Internet, Location (for live weather METAR data)
